#include <iostream>

int main() {
  std::cout << "Hello, world!\n";
  return 0;
}